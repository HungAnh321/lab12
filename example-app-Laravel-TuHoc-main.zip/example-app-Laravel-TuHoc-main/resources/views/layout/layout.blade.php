@include('layout.header')
@include('layout.slider')
<div class="col-sm-9 padding-right">
    @yield('content')
</div>
@include('layout.footer')
