@extends('admin_layout.admin_layout')
@section('admin_content')
    <h3> Xin chao
        {{session('admin_name')}}
    </h3>
@endsection
